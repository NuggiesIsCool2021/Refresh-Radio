import { loadClient, loadEvents, loadCommands } from './utils/initClient.js'


// The client init
( async () => {
    const client = await loadClient()
    loadCommands ( client )
    loadEvents( client )
})()