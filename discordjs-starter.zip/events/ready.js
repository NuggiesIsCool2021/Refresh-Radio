
// To check if ur client is ready.
export default ( client ) => {
    console.log(`${client.user.tag} is Ready.`)
}