


// DO NOT REMOVE THIS
// Thats the event to listen for a new command.
export default ( message, client ) => {
     
    if(!message.content.startsWith(client.PREFIX) || message.author.bot) return
    const args = message.content.slice(client.PREFIX.length).split(/ +/)
    const commandName = args.shift().toLowerCase()
    const commandToExecute = client.commands.get(commandName) || client.commands.find(thisCommand => thisCommand.aliases.includes(commandName))
    if(!commandToExecute) return
    try {
      commandToExecute.execute(message, args, client);
    } catch (error) {
      message.reply(error)
    }
}

