

// An example of a command.
export default {
    name: 'example', // ur command name
    aliases: ['ex', 'examp'], // ur command aliases.
    execute: async ( message, args, client ) => { // Your callaback.
        console.log(client)
    }
}