
import { Intents, Client, Collection} from 'discord.js'
import fs from 'fs'

// Create new client.
export const loadClient = async ( ) => {
    const client = new Client({
        intents: 
        [
        Intents.FLAGS.GUILDS, 
        Intents.FLAGS.GUILD_MEMBERS, 
        Intents.FLAGS.GUILD_BANS, 
        Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,
        Intents.FLAGS.GUILD_INTEGRATIONS,
        Intents.FLAGS.GUILD_WEBHOOKS,
        Intents.FLAGS.GUILD_INVITES,
        Intents.FLAGS.GUILD_VOICE_STATES,
        Intents.FLAGS.GUILD_PRESENCES,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
        Intents.FLAGS.GUILD_MESSAGE_TYPING,
        Intents.FLAGS.DIRECT_MESSAGES,
        Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,
        Intents.FLAGS.DIRECT_MESSAGE_TYPING
      ],
      partials: ["CHANNEL"]

    })
    const dotenv = await import('dotenv')
    dotenv.config({path: './src/config/.env'})

    client.login(process.env.CLIENT_SECRET)
    client.PREFIX = process.env.CLIENT_PREFIX

    return client
}


// Function to load all commands.
export const loadCommands = async ( client ) => {
    client.commands = new Collection()
    const allCommands = fs.readdirSync('./src/commands').filter(file => file.endsWith('.js'))
    for (let file of allCommands) {
        const command = (await import(`../commands/${file}`)).default
        client.commands.set(command.name, command)
    }
}

// Function to load all events.
export const loadEvents = async ( client ) => {
    const allEvents = fs.readdirSync('./src/events').filter(file => file.endsWith('.js'))
    for (let file of allEvents) {
        const { default: execute } = await import(`../events/${file}`)
        let fileName = removeFileExtension(file)
        client.on(fileName, (...args) => execute(...args, client))
    }
}


// Function that removes the extension of a file.
const removeFileExtension = fileName => {
	const fileArray = fileName.split('.')
	fileArray.pop()
	return fileArray.join('.')
}

// Created by 'niiy.'#2332